
Imports System.Deployment
Imports System.IO
Imports System.IO.Compression
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Text

<Assembly: AssemblyTitle("Streamlink for Windows")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("Streamlink")>
<Assembly: AssemblyProduct("Streamlink for Windows")>
<Assembly: AssemblyCopyright("Streamlink")>
<Assembly: AssemblyTrademark("Streamlink for Windows")>
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>

Module Module1
    Public url_trabajo_app As String = System.Reflection.Assembly.GetExecutingAssembly().CodeBase
    Sub Main()
        Try
            url_trabajo_app = url_trabajo_app.Replace("file:///", "")
            url_trabajo_app = System.IO.Path.GetDirectoryName(url_trabajo_app)
            Dim temp_patch_rtv As String = Path.GetTempPath & "\RTV_STREAMLINK_FOR_WINDOWS"
            Dim temp_zip_patch_rtv As String = temp_patch_rtv & "\STREAMLINK_RELEASE.zip"
            Try
                Console.OutputEncoding = Encoding.UTF8
                Console.InputEncoding = Encoding.UTF8
            Catch
                'Error al definir encoding
            End Try

            Dim argumentos_finales As String = Environment.CommandLine
            If argumentos_finales.StartsWith("""") AndAlso argumentos_finales.Length > 1 Then
                Dim ix As Integer = argumentos_finales.IndexOf("""", 1)

                If ix <> -1 Then
                    argumentos_finales = argumentos_finales.Substring(ix + 1).TrimStart()
                End If
            Else
                Dim ix As Integer = argumentos_finales.IndexOf(" ")

                If ix <> -1 Then
                    argumentos_finales = argumentos_finales.Substring(ix + 1).TrimStart()
                End If
            End If

            Dim requiere_extraccion As Boolean = True

            If IO.Directory.Exists(temp_patch_rtv) Then
                Dim temp_ver_anterior As String = temp_patch_rtv & "\VERSION.txt"
                Dim temp_ver_embed As String = temp_patch_rtv & "\VERSION_EMBED.txt"
                BorrarArchivoSiExiste(temp_ver_embed)
                Dim _assembly As [Assembly] = [Assembly].GetExecutingAssembly()
                Dim _filestream As Stream = _assembly.GetManifestResourceStream("VERSION.txt")
                CopyStream(_filestream, temp_ver_embed)
                If IO.File.ReadAllText(temp_ver_anterior, Encoding.UTF8) = IO.File.ReadAllText(temp_ver_embed, Encoding.UTF8) Then
                    requiere_extraccion = False
                End If
            End If

            If requiere_extraccion = True Then
                Console.WriteLine("[Streamlink] Extracting program ...")
                Finalizar_Todos_Los_EXE(temp_patch_rtv)
                BorrarDirectorioSiExiste(temp_patch_rtv)
                IO.Directory.CreateDirectory(temp_patch_rtv)
                Dim _assembly As [Assembly] = [Assembly].GetExecutingAssembly()
                Dim _filestream As Stream = _assembly.GetManifestResourceStream("STREAMLINK_RELEASE.zip")
                CopyStream(_filestream, temp_zip_patch_rtv)
                DescomprimirArchivoZIP(temp_zip_patch_rtv, temp_patch_rtv)
                IO.File.Delete(temp_zip_patch_rtv)
                Desbloquear_Todos_Los_EXE(temp_patch_rtv) 'Intentar desbloquear ruta temporal de Streamlink
                Console.WriteLine("[Streamlink] Program successfully extracted")
            End If
            Console.WriteLine("[Streamlink for Windows]")
            Dim info = New ProcessStartInfo(Chr(34) & temp_patch_rtv & "\Python 3.5.2\python.exe" & Chr(34), Chr(34) & temp_patch_rtv & "\Streamlink\streamlink-script.py" & Chr(34) & " --config " & Chr(34) & url_trabajo_app & "\streamlinkrc" & Chr(34) & " --rtmp-rtmpdump " & Chr(34) & temp_patch_rtv & "\Streamlink\rtmpdump\rtmpdump.exe" & Chr(34) & " " & argumentos_finales)
            info.UseShellExecute = False
            Dim proc = Process.Start(info)
            proc.WaitForExit()
        Catch ex As Exception
            Console.WriteLine("An error occurred :(")
        End Try
        'Threading.Thread.Sleep(Threading.Timeout.Infinite)
    End Sub

    Public Sub CopyStream(stream As Stream, destPath As String)
        Using fileStream = New FileStream(destPath, FileMode.Create, FileAccess.Write)
            stream.CopyTo(fileStream)
        End Using
    End Sub

    Sub BorrarDirectorioSiExiste(ByVal URL As String)
        If IO.Directory.Exists(URL) Then
            IO.Directory.Delete(URL, True)
        End If
    End Sub

    Sub BorrarArchivoSiExiste(ByVal URL As String)
        If IO.File.Exists(URL) Then
            IO.File.Delete(URL)
        End If
    End Sub

    Function Finalizar_Todos_Los_EXE(ByVal ruta As String)
        Dim SourceDir As DirectoryInfo = New DirectoryInfo(ruta)
        Dim pathIndex As Integer

        If SourceDir.Exists Then
            pathIndex = ruta.LastIndexOf("\")
            For Each childFile As FileInfo In SourceDir.GetFiles("*", SearchOption.AllDirectories).Where(Function(file) file.Extension.ToLower = ".exe")
                For Each prog As Process In Process.GetProcesses
                    If prog.ProcessName = childFile.Name.Remove(childFile.Name.LastIndexOf(".")) Then
                        prog.Kill() 'Matar proceso encontrado en la ubicacion actual
                        prog.WaitForExit() 'Esperar hasta que el proceso se haya ido
                    End If
                Next
            Next
        Else
            'Console.WriteLine("El directorio donde se deben finalizar los procesos no existe")
        End If

    End Function

    Function Desbloquear_Todos_Los_EXE(ByVal ruta As String)
        On Error Resume Next 'Solo usar para este programa, ya que lo normal es disparar un error
        Dim SourceDir As DirectoryInfo = New DirectoryInfo(ruta)
        Dim pathIndex As Integer

        If SourceDir.Exists Then
            pathIndex = ruta.LastIndexOf("\")
            For Each childFile As FileInfo In SourceDir.GetFiles("*", SearchOption.AllDirectories).Where(Function(file) file.Extension.ToLower = ".exe")
                FileUnblocker.UnblockFile(childFile.FullName) 'Desbloquear el .EXE actual
            Next
        Else
            'Console.WriteLine("El directorio donde necesito desbloquear archivos no existe :(")
        End If
    End Function

    Public Function DescomprimirArchivoZIP(ByVal Ruta_ZIP As String, ByVal Carpeta_Salida As String)
        Using archive As ZipArchive = ZipFile.OpenRead(Ruta_ZIP)
            For Each entry As ZipArchiveEntry In archive.Entries
                Dim entryFullname = Path.Combine(Carpeta_Salida, entry.FullName)
                Dim entryPath = Path.GetDirectoryName(entryFullname)
                If (Not (Directory.Exists(entryPath))) Then
                    Directory.CreateDirectory(entryPath)
                End If

                Dim entryFn = Path.GetFileName(entryFullname)
                If (Not String.IsNullOrEmpty(entryFn)) Then
                    entry.ExtractToFile(entryFullname, True)
                End If
            Next
        End Using
    End Function

End Module

Public Class FileUnblocker

    <DllImport("kernel32", CharSet:=CharSet.Unicode, SetLastError:=True)>
    Public Shared Function DeleteFile(name As String) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    Public Shared Sub UnblockPath(path As String)
        Dim files As String() = System.IO.Directory.GetFiles(path)
        Dim dirs As String() = System.IO.Directory.GetDirectories(path)

        For Each file As String In files
            UnblockFile(file)
        Next

        For Each dir As String In dirs
            UnblockPath(dir)
        Next

    End Sub

    Public Shared Function UnblockFile(fileName As String) As Boolean
        Return DeleteFile(fileName & Convert.ToString(":Zone.Identifier"))
    End Function

End Class
