Imports System.Reflection
Imports System.Deployment
Imports System.Text

<Assembly: AssemblyTitle("Streamlink for Windows")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("Vladimir Damian Ianuzo")>
<Assembly: AssemblyProduct("Streamlink for Windows")>
<Assembly: AssemblyCopyright("Vladimir Damian Ianuzo")>
<Assembly: AssemblyTrademark("Streamlink for Windows")>
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>

Module Module1

    Public url_trabajo_app As String = System.Reflection.Assembly.GetExecutingAssembly().CodeBase
    Sub Main()
        On Error Resume Next
        url_trabajo_app = url_trabajo_app.Replace("file:///", "")
        url_trabajo_app = System.IO.Path.GetDirectoryName(url_trabajo_app)

        Console.OutputEncoding = Encoding.UTF8
        Console.InputEncoding = Encoding.UTF8

        Dim argumentos_finales As String = Environment.CommandLine
        If argumentos_finales.StartsWith("""") AndAlso argumentos_finales.Length > 1 Then
            Dim ix As Integer = argumentos_finales.IndexOf("""", 1)

            If ix <> -1 Then
                argumentos_finales = argumentos_finales.Substring(ix + 1).TrimStart()
            End If
        Else
            Dim ix As Integer = argumentos_finales.IndexOf(" ")

            If ix <> -1 Then
                argumentos_finales = argumentos_finales.Substring(ix + 1).TrimStart()
            End If
        End If

        Console.WriteLine("[Streamlink for Windows]")
        Dim info = New ProcessStartInfo(Chr(34) & url_trabajo_app & "\Python 3.5.2\python.exe" & Chr(34), Chr(34) & url_trabajo_app & "\Streamlink\streamlink-script.py" & Chr(34) & " --config " & Chr(34) & url_trabajo_app & "\streamlinkrc" & Chr(34) & " --rtmp-rtmpdump " & Chr(34) & url_trabajo_app & "\Streamlink\rtmpdump\rtmpdump.exe" & Chr(34) & " " & argumentos_finales)
        info.UseShellExecute = False
        Dim proc = Process.Start(info)
        proc.WaitForExit()
        'Threading.Thread.Sleep(Threading.Timeout.Infinite)
    End Sub

End Module
