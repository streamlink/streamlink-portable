Requirements:
-Windows Vista SP2 or later
-.NET Framework 4.5 (Dont required in Windows 8 or later)
https://www.microsoft.com/en-US/download/details.aspx?id=30653
-Visual C++ Redistributable (Dont required in Windows 10 or later)
https://www.microsoft.com/en-US/download/details.aspx?id=48145

For more info visit https://github.com/streamlink/streamlink or https://streamlink.github.io