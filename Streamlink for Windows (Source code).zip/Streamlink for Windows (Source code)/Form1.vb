﻿Imports System.ComponentModel
Imports System.IO
Imports System.Net
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Security.Cryptography
Imports System.Text

Public Class Form1
    Public Shared url_trabajo_app As String = IO.Path.GetDirectoryName(Application.ExecutablePath)
    Dim WithEvents Descargador_HTML As New WebClient() 'Descargador de datos
    Dim UserAgent_1 As String = "Mozilla/5.0 (Android; Mobile; rv:30.0) Gecko/30.0 Firefox/30.0" 'Android (Mobile)
    Dim UserAgent_2 As String = "Dalvik/1.6.0 (Linux; U; Android 4.4.2; TegraNote-P1640 Build/KOT49H)" 'Android (Tablet)
    Dim UserAgent_3 As String = "Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0" 'Windows (Escritorio)

    'Para tareas que requieren WebRequest y WebResponse
    Dim myHttpWebRequest As HttpWebRequest
    Dim myHttpWebResponse As HttpWebResponse
    '

    'Almacen de datos actuales
    Dim VERSION_ACTUAL As String = ""
    '

    Public WithEvents BW_PASOS As New ExtendedBackgroundWorker
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.KeyPreview = True
        Me.Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location) 'El icono sera el mismo que el de la aplicacion
        Me.DoubleBuffered = True 'Evitar que ocurra flickering en la UI
        Me.ClientSize = Panel2.ClientSize
        CheckForIllegalCrossThreadCalls = False 'Activar manejo total por parte de backgroundworkers
        IO.Directory.SetCurrentDirectory(url_trabajo_app)

        'Averiguar si hay permisos de escritura
        If Averiguar_Permisos_Escritura() = False Then
            Msgbox_THREADSAFE("I dont have write permissions :(" & vbNewLine & "Try running me with administrator rights.", MsgBoxStyle.Critical, "Error")
            Application.Exit()
            Application.ExitThread()
            Return
        End If
        '

        Desbloquear_Todos_Los_EXE("Files")

    End Sub

    Public Function Averiguar_Permisos_Escritura() As Boolean
        Try
            IO.File.WriteAllText("TEST.rtv", "", Encoding.UTF8)
            IO.File.Delete("TEST.rtv")
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function GetPageHTMLCustom(ByVal URL As String, ByVal UserAgent_Custom As String, ByVal Referer_Custom As String, Optional ByVal Cookies As String = "") As String
        Dim RESULTADO As String = ""
        Descargador_HTML.Encoding = Encoding.UTF8
        Descargador_HTML.Headers.Clear()
        Descargador_HTML.Headers(Net.HttpRequestHeader.Referer) = Referer_Custom
        Descargador_HTML.Headers(Net.HttpRequestHeader.UserAgent) = UserAgent_Custom
        Descargador_HTML.Headers(Net.HttpRequestHeader.Cookie) = Cookies
        Try
            RESULTADO = Descargador_HTML.DownloadString(URL) 'Intentar obtener resultado de manera directa
        Catch falla As WebException 'Intentar obtener resultado ignorando errores
            Using sr = New StreamReader(falla.Response.GetResponseStream())
                RESULTADO = sr.ReadToEnd()
            End Using
        End Try
        Return RESULTADO
    End Function

    Public Function GetPageHTMLCustom_POST(ByVal POST As String, ByVal URL As String, ByVal UserAgent_Custom As String, ByVal Referer_Custom As String, Optional ByVal Cookies As String = "") As String
        Dim RESULTADO As String = ""
        Descargador_HTML.Encoding = Encoding.UTF8
        Descargador_HTML.Headers.Clear()
        Descargador_HTML.Headers(Net.HttpRequestHeader.Referer) = Referer_Custom
        Descargador_HTML.Headers(Net.HttpRequestHeader.UserAgent) = UserAgent_Custom
        Descargador_HTML.Headers(Net.HttpRequestHeader.Cookie) = Cookies
        Descargador_HTML.Headers.Add("Content-Type: application/x-www-form-urlencoded; charset=UTF-8")

        Try
            RESULTADO = Descargador_HTML.UploadString(URL, POST) 'Intentar obtener resultado de manera directa
        Catch falla As WebException 'Intentar obtener resultado ignorando errores
            Using sr = New StreamReader(falla.Response.GetResponseStream())
                RESULTADO = sr.ReadToEnd()
            End Using
        End Try
        Return RESULTADO
    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If sender.Text = "Not completed" Then
            If BW_PASOS.IsBusy = False Then
                BW_PASOS.RunWorkerAsync("PASO1")
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Button2.Text = "Completed" And sender.text = "Not completed" Then
            If BW_PASOS.IsBusy = False Then
                BW_PASOS.RunWorkerAsync("PASO2")
            End If
        End If
    End Sub

    Sub BorrarDirectorioSiExiste(ByVal URL As String)
        If IO.Directory.Exists(URL) Then
            IO.Directory.Delete(URL, True)
        End If
    End Sub

    Private Sub BW_PASOS_DoWork(sender As Object, e As DoWorkEventArgs) Handles BW_PASOS.DoWork
        CancelarInteraccionesInternet()
        If e.Argument = "PASO1" Then
            Try

                Button2.Text = "Loading (1/1)"

                BorrarDirectorioSiExiste("Files\TEMP")
                IO.Directory.CreateDirectory("Files\TEMP")

                Dim strlk_url As String = "https://github.com/streamlink/streamlink/archive/master.zip"
                VERSION_ACTUAL = ObtenerETAG_HTTPHEADER(strlk_url)

                If IO.Directory.Exists("Release") Then
                    If IO.File.Exists("Release\VERSION.txt") Then
                        Dim vers_check As String = IO.File.ReadAllText("Release\VERSION.txt")
                        If vers_check = VERSION_ACTUAL Then
                            Dim result As Integer = MSGBOX_INTERACTIVE_THREADSAFE("It looks like you already have the latest available version." & vbNewLine & "¿Continue anyway?", "Advice", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                            If result = DialogResult.Yes Then
                                'El usuario acepto actualizar de todas formas
                            Else
                                Button2.Text = "Not completed"
                                Return
                            End If
                        End If
                    End If
                End If

                Descargador_HTML.DownloadFile(strlk_url, "Files\TEMP\Streamlink_Latest.zip")

                Button2.Text = "Completed"

            Catch
                Button2.Text = "Not completed"
            End Try
        End If

        If e.Argument = "PASO2" Then
            Try
                Button3.Text = "Loading (1/3)"

                Dim ruta_comprimido As String = Chr(34) & url_trabajo_app & "\Files\TEMP\Streamlink_Latest.zip" & Chr(34)
                Dim destino_comprimido As String = Chr(34) & url_trabajo_app & "\Files\TEMP" & Chr(34)
                BorrarDirectorioSiExiste("Files\TEMP\streamlink-master")
                EjecutarYEsperar("Files\7zip\7za.exe", "-y x " & ruta_comprimido & " -o" & destino_comprimido) 'Si hay que descomprimir


                For Each archivin As String In IO.Directory.GetFiles("Files\TEMP\streamlink-master", "*.*", SearchOption.TopDirectoryOnly)
                    IO.File.Delete(archivin)
                Next

                For Each carpetin As String In IO.Directory.GetDirectories("Files\TEMP\streamlink-master")
                    carpetin = carpetin.Replace("/", "\")
                    If (carpetin.EndsWith("\src") Or carpetin.EndsWith("\win32")) = False Then
                        IO.Directory.Delete(carpetin, True)
                    End If
                Next

                MoveAllItems("Files\TEMP\streamlink-master\src", "Files\TEMP\streamlink-master")
                MoveAllItems("Files\TEMP\streamlink-master\win32", "Files\TEMP\streamlink-master")
                BorrarDirectorioSiExiste("Files\TEMP\streamlink-master\src")
                BorrarDirectorioSiExiste("Files\TEMP\streamlink-master\win32")

                Dim argparser_py_location As String = "Files\TEMP\streamlink-master\streamlink_cli\argparser.py"
                Dim argparser_py As String = IO.File.ReadAllText(argparser_py_location, Encoding.UTF8)
                Dim argparser_py_replace As String = "usage='%(prog)s [OPTIONS] [URL] [STREAM]',".Replace("'", Chr(34))
                Dim argparser_py_replace_end As String = "usage='streamlink.bat [OPTIONS] [URL] [STREAM]',".Replace("'", Chr(34))
                argparser_py = argparser_py.Replace(argparser_py_replace, argparser_py_replace_end)
                IO.File.WriteAllText(argparser_py_location, argparser_py, Encoding.UTF8)

                Dim constants_py_location As String = "Files\TEMP\streamlink-master\streamlink_cli\constants.py"
                Dim constants_py As String = IO.File.ReadAllText(constants_py_location, Encoding.UTF8)
                Dim constants_py_replace As String = "CONFIG_FILES = [os.path.join(APPDATA, 'streamlink', 'streamlinkrc')]".Replace("'", Chr(34))
                Dim constants_py_replace_end As String = "CONFIG_FILES = [os.path.realpath('Streamlink/streamlinkrc')]".Replace("'", Chr(34))
                constants_py = constants_py.Replace(constants_py_replace, constants_py_replace_end)
                IO.File.WriteAllText(constants_py_location, constants_py, Encoding.UTF8)

                Dim rtmpdump_py_location As String = "Files\TEMP\streamlink-master\streamlink\stream\rtmpdump.py"
                Dim rtmpdump_py As String = IO.File.ReadAllText(rtmpdump_py_location, Encoding.UTF8)
                Dim rtmpdump_py_replace As String = "self.cmd = self.session.options.get('rtmp-rtmpdump')".Replace("'", Chr(34))
                Dim rtmpdump_py_replace_end As String = "self.cmd = os.path.realpath('Streamlink/rtmpdump/rtmpdump.exe')".Replace("'", Chr(34))
                rtmpdump_py = rtmpdump_py.Replace(rtmpdump_py_replace, rtmpdump_py_replace_end)
                rtmpdump_py = "import os" & vbNewLine & rtmpdump_py
                IO.File.WriteAllText(rtmpdump_py_location, rtmpdump_py, Encoding.UTF8)

                ruta_comprimido = Chr(34) & url_trabajo_app & "\Files\Resources\Streamlink_Patches.zip" & Chr(34)
                destino_comprimido = Chr(34) & url_trabajo_app & "\Files\TEMP\streamlink-master" & Chr(34)
                EjecutarYEsperar("Files\7zip\7za.exe", "-y x " & ruta_comprimido & " -o" & destino_comprimido) 'Si hay que descomprimir

                Button3.Text = "Loading (2/3)"

                Finalizar_Todos_Los_EXE("Release")
                BorrarDirectorioSiExiste("Release")
                IO.Directory.CreateDirectory("Release\Python 3.5.2")

                MoveAllItems("Files\TEMP\streamlink-master", "Release\Streamlink")
                BorrarDirectorioSiExiste("Files\TEMP\streamlink-master")

                ruta_comprimido = Chr(34) & url_trabajo_app & "\Files\Resources\python-3.5.2-embed-win32.zip" & Chr(34)
                destino_comprimido = Chr(34) & url_trabajo_app & "\Release\Python 3.5.2" & Chr(34)
                EjecutarYEsperar("Files\7zip\7za.exe", "-y x " & ruta_comprimido & " -o" & destino_comprimido) 'Si hay que descomprimir

                Button3.Text = "Loading (3/3)"

                ruta_comprimido = Chr(34) & url_trabajo_app & "\Files\Resources\Streamlink_Release.zip" & Chr(34)
                destino_comprimido = Chr(34) & url_trabajo_app & "\Release" & Chr(34)
                EjecutarYEsperar("Files\7zip\7za.exe", "-y x " & ruta_comprimido & " -o" & destino_comprimido) 'Si hay que descomprimir

                IO.File.WriteAllText("Release\VERSION.txt", VERSION_ACTUAL)

                'BorrarDirectorioSiExiste("Files\TEMP")
                Desbloquear_Todos_Los_EXE("Release")

                Button3.Text = "Completed"

                Msgbox_THREADSAFE("Build " & VERSION_ACTUAL & " was successful released." & vbNewLine & "You can find it inside the Release folder.", MsgBoxStyle.Information, "Advice")

            Catch
                Button3.Text = "Not completed"
            End Try
        End If

    End Sub


    Function Finalizar_Todos_Los_EXE(ByVal ruta As String)

        Dim SourceDir As DirectoryInfo = New DirectoryInfo(ruta)
        Dim pathIndex As Integer
        pathIndex = ruta.LastIndexOf("\")
        ' the source directory must exist, otherwise throw an exception

        If SourceDir.Exists Then
            For Each childFile As FileInfo In SourceDir.GetFiles("*", SearchOption.AllDirectories).Where(Function(file) file.Extension.ToLower = ".exe")
                Dim proceso_updater_actual As String = Process.GetCurrentProcess.ProcessName
                If childFile.Name.ToLower.Contains(proceso_updater_actual.ToLower) = False Then 'Si el proceso obtenido no es el actual
                    For Each prog As Process In Process.GetProcesses
                        If prog.ProcessName = childFile.Name.Remove(childFile.Name.LastIndexOf(".")) Then
                            prog.Kill() 'Matar proceso encontrado en la ubicacion actual
                            prog.WaitForExit() 'Esperar hasta que el proceso se haya ido
                        End If
                    Next
                End If
            Next
        Else
            Console.WriteLine("El directorio donde se deben finalizar los procesos no existe")
        End If

    End Function

    Function Desbloquear_Todos_Los_EXE(ByVal ruta As String)
        Dim SourceDir As DirectoryInfo = New DirectoryInfo(ruta)
        Dim pathIndex As Integer
        pathIndex = ruta.LastIndexOf("\")
        ' the source directory must exist, otherwise throw an exception

        If SourceDir.Exists Then
            For Each childFile As FileInfo In SourceDir.GetFiles("*", SearchOption.AllDirectories).Where(Function(file) file.Extension.ToLower = ".exe")
                Dim proceso_updater_actual As String = Application.ExecutablePath.Remove(0, Application.ExecutablePath.LastIndexOf("\") + 1)
                proceso_updater_actual = proceso_updater_actual.Remove(proceso_updater_actual.LastIndexOf("."))
                If childFile.Name.ToLower.Contains(proceso_updater_actual.ToLower) = False Then 'Si el proceso obtenido no es el actual

                    FileUnblocker.UnblockFile(childFile.FullName) 'Desbloquear el .EXE actual

                End If
            Next
        Else
            Console.WriteLine("El directorio donde necesito desbloquear archivos no existe :(")
        End If
    End Function

    Sub MoveAllItems(ByVal fromPath As String, ByVal toPath As String)
        ''Create the target directory if necessary
        Dim toPathInfo = New DirectoryInfo(toPath)
        If (Not toPathInfo.Exists) Then
            toPathInfo.Create()
        End If
        Dim fromPathInfo = New DirectoryInfo(fromPath)
        ''move all files
        For Each file As FileInfo In fromPathInfo.GetFiles()
            file.MoveTo(Path.Combine(toPath, file.Name))
        Next
        ''move all folders
        For Each dir As DirectoryInfo In fromPathInfo.GetDirectories()
            dir.MoveTo(Path.Combine(toPath, dir.Name))
        Next
    End Sub


    Function ObtenerETAG_HTTPHEADER(ByVal URL As String) As String
        ' Creates an HttpWebRequest with the specified URL. 
        myHttpWebRequest = CType(WebRequest.Create(URL), HttpWebRequest)
        'Establecer el metodo de entrega
        myHttpWebRequest.Method = "HEAD"
        ' Sends the HttpWebRequest and waits for a response.
        myHttpWebResponse = CType(myHttpWebRequest.GetResponse(), HttpWebResponse)
        ' Displays all the Headers present in the response received from the URI.
        Console.WriteLine(ControlChars.Lf + ControlChars.Cr + "The following headers were received in the response")
        'The Headers property is a WebHeaderCollection. Use it's properties to traverse the collection and display each header.
        Dim i As Integer
        Dim ETAG As String = ""
        While i < myHttpWebResponse.Headers.Count
            i = i + 1
            If myHttpWebResponse.Headers.Keys(i) = "ETag" Then
                ETAG = myHttpWebResponse.Headers(i)
                ETAG = ETAG.Replace(Chr(34), "")
                i = myHttpWebResponse.Headers.Count
            End If
        End While
        Return ETAG
        myHttpWebRequest.Abort()
        myHttpWebResponse.Close()
        myHttpWebResponse.Dispose()
    End Function

    Sub THREADSAFE_CALL(ByVal Funcion As MethodInvoker)
        Me.Invoke(DirectCast(Funcion, MethodInvoker))
        'Ejemplo:
        'THREADSAFE_CALL(Sub()
        ' MsgBox("Prueba")
        ' End Sub)
    End Sub

    Sub CancelarInteraccionesInternet()
        On Error Resume Next
        Descargador_HTML.CancelAsync()
        'Descargador_HTML.Dispose()
        myHttpWebRequest.Abort()
        myHttpWebResponse.Close()
        myHttpWebResponse.Dispose()
    End Sub

    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        On Error Resume Next
        Descargador_HTML.CancelAsync()
        Descargador_HTML.Dispose()
        BW_PASOS.CancelAsync()
        BW_PASOS.CancelImmediately()
        BW_PASOS.Dispose()
        Process.GetCurrentProcess.Kill()
    End Sub

    Function Msgbox_THREADSAFE(ByVal Mensaje As String, ByVal Estilo As MsgBoxStyle, ByVal Titulo As String)
        THREADSAFE_CALL(Sub()
                            MsgBox(Mensaje, Estilo, Titulo)
                        End Sub)
    End Function

    Function Msgbox_Interactive_THREADSAFE(ByVal Mensaje As String, ByVal Titulo As String, ByVal Botones As MessageBoxButtons, ByVal Icono As MessageBoxIcon)
        Dim msgbox_result As Integer = MsgBoxResult.No
        THREADSAFE_CALL(Sub()
                            msgbox_result = MessageBox.Show(Mensaje, Titulo, Botones, Icono)
                        End Sub)
        Return msgbox_result
    End Function

    Function EjecutarYEsperar(ByVal Ruta As String, ByVal Argumentos As String)

        If IO.File.Exists(Ruta) = False Then
            Msgbox_THREADSAFE("A required file is missing :(", MsgBoxStyle.Critical, "Error")
            Process.GetCurrentProcess.Kill()
        End If

        Dim umaka As New Process
        umaka.StartInfo.FileName = Ruta
        umaka.StartInfo.Arguments = Argumentos
        umaka.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        umaka.Start()
        umaka.WaitForExit()
    End Function

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Escape Then
            Panel2.Focus() 'Si se presiona ESC se quita el foco
        End If
    End Sub

End Class

Public Class FileUnblocker

    <DllImport("kernel32", CharSet:=CharSet.Unicode, SetLastError:=True)>
    Public Shared Function DeleteFile(name As String) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    Public Shared Sub UnblockPath(path As String)
        Dim files As String() = System.IO.Directory.GetFiles(path)
        Dim dirs As String() = System.IO.Directory.GetDirectories(path)

        For Each file As String In files
            UnblockFile(file)
        Next

        For Each dir As String In dirs
            UnblockPath(dir)
        Next

    End Sub

    Public Shared Function UnblockFile(fileName As String) As Boolean
        Return DeleteFile(fileName & Convert.ToString(":Zone.Identifier"))
    End Function
End Class
